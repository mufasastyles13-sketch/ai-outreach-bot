/*
# Create leads and messages tables

## Overview
Creates the core data model for the AI Outreach Bot MVP.
Leads are prospects a user wants to reach out to. Messages are
AI-generated outreach drafts (email or WhatsApp) tied to a lead.
Each user only sees and manages their own data.

## New Tables

### leads
- `id` (uuid, primary key)
- `user_id` (uuid, owner, defaults to auth.uid())
- `name` (text, the lead's full name)
- `email` (text, lead's email address, nullable)
- `phone` (text, lead's phone/WhatsApp number, nullable)
- `company` (text, lead's company, nullable)
- `role` (text, lead's job title/role, nullable)
- `industry` (text, lead's industry, nullable)
- `notes` (text, free-form context about the lead, nullable)
- `tags` (text[], array of tags for CRM-style filtering)
- `status` (text, one of: new, contacted, responded, closed — defaults to new)
- `created_at` (timestamptz, defaults to now())

### messages
- `id` (uuid, primary key)
- `user_id` (uuid, owner, defaults to auth.uid())
- `lead_id` (uuid, foreign key to leads, cascade on delete)
- `channel` (text, either 'email' or 'whatsapp')
- `subject` (text, email subject line, nullable for whatsapp)
- `body` (text, the generated message content)
- `tone` (text, the tone used for generation: friendly, formal, concise, persuasive)
- `goal` (text, the goal of the outreach, nullable)
- `status` (text, one of: draft, sent, replied — defaults to draft)
- `created_at` (timestamptz, defaults to now())

## Security
- RLS enabled on both tables.
- Owner-scoped CRUD: each authenticated user can only access rows they own.
- `user_id` defaults to `auth.uid()` so client inserts that omit it still succeed.
- Messages are scoped through the leads table via user_id ownership.

## Important Notes
1. The app has a sign-in screen, so policies are `TO authenticated` only.
2. Both tables use `DEFAULT auth.uid()` on user_id.
3. Indexes added on user_id and lead_id for query performance.
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text,
  phone text,
  company text,
  role text,
  industry text,
  notes text,
  tags text[] NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'responded', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  lead_id uuid NOT NULL REFERENCES leads(id) ON DELETE CASCADE,
  channel text NOT NULL CHECK (channel IN ('email', 'whatsapp')),
  subject text,
  body text NOT NULL,
  tone text NOT NULL DEFAULT 'friendly',
  goal text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'sent', 'replied')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_leads_user_id ON leads(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_lead_id ON messages(lead_id);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_leads" ON leads;
CREATE POLICY "select_own_leads" ON leads FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_leads" ON leads;
CREATE POLICY "insert_own_leads" ON leads FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_leads" ON leads;
CREATE POLICY "update_own_leads" ON leads FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_leads" ON leads;
CREATE POLICY "delete_own_leads" ON leads FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "select_own_messages" ON messages;
CREATE POLICY "select_own_messages" ON messages FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_messages" ON messages;
CREATE POLICY "insert_own_messages" ON messages FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_messages" ON messages;
CREATE POLICY "update_own_messages" ON messages FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_messages" ON messages;
CREATE POLICY "delete_own_messages" ON messages FOR DELETE
  TO authenticated USING (auth.uid() = user_id);