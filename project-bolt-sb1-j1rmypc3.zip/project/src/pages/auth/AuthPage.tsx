import { useState } from 'react';
import { Send, Mail, Lock, ArrowRight, Sparkles } from 'lucide-react';
import { useAuth } from '../../lib/auth';

export function AuthPage({ mode }: { mode: 'login' | 'signup' }) {
  const { signIn, signUp } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const isLogin = mode === 'login';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const result = isLogin
      ? await signIn(email, password)
      : await signUp(email, password);

    setLoading(false);

    if (result.error) {
      setError(result.error);
    } else if (!isLogin) {
      setError(null);
      // After signup, Supabase auto-signs in (email confirmation is off)
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side — form */}
      <div className="flex-1 flex flex-col justify-center px-6 py-12 lg:px-12">
        <div className="mx-auto w-full max-w-md">
          <a href="#/" className="inline-flex items-center gap-2 mb-8">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-600 to-accent-600 text-white">
              <Send className="h-4 w-4" />
            </div>
            <span className="text-lg font-bold text-slate-900">OutreachAI</span>
          </a>

          <h1 className="text-2xl font-bold text-slate-900">
            {isLogin ? 'Welcome back' : 'Create your account'}
          </h1>
          <p className="mt-2 text-sm text-slate-500">
            {isLogin
              ? 'Sign in to your dashboard to manage leads and outreach.'
              : 'Start automating your outreach in under 2 minutes. No credit card required.'}
          </p>

          {error && (
            <div className="mt-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 animate-fade-in">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input-field pl-10"
                  placeholder="you@example.com"
                />
              </div>
            </div>

            <div>
              <label className="mb-1.5 block text-sm font-medium text-slate-700">Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  required
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  minLength={6}
                  className="input-field pl-10"
                  placeholder="At least 6 characters"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full"
            >
              {loading ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                  {isLogin ? 'Signing in...' : 'Creating account...'}
                </>
              ) : (
                <>
                  {isLogin ? 'Sign In' : 'Create Account'}
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            {isLogin ? "Don't have an account? " : 'Already have an account? '}
            <a
              href={isLogin ? '#/signup' : '#/login'}
              className="font-semibold text-brand-600 hover:text-brand-700"
            >
              {isLogin ? 'Sign up free' : 'Sign in'}
            </a>
          </p>
        </div>
      </div>

      {/* Right side — branding */}
      <div className="hidden lg:flex lg:flex-1 relative overflow-hidden bg-gradient-to-br from-brand-600 via-brand-700 to-accent-700">
        <div className="absolute inset-0">
          <div className="absolute top-20 left-20 h-72 w-72 rounded-full bg-white/10 blur-3xl animate-float" />
          <div className="absolute bottom-20 right-20 h-96 w-96 rounded-full bg-accent-300/20 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative flex flex-col justify-center px-16 text-white">
          <div className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-sm font-medium backdrop-blur-sm w-fit">
            <Sparkles className="h-4 w-4" /> AI-Powered Outreach
          </div>

          <h2 className="mt-6 text-4xl font-bold leading-tight">
            Win clients faster with personalized outreach on autopilot.
          </h2>

          <p className="mt-4 text-lg text-brand-50/90">
            Generate tailored cold emails and WhatsApp messages, organize leads, and track responses — all in one place.
          </p>

          <div className="mt-10 space-y-4">
            {[
              'AI-generated messages in seconds',
              'Email + WhatsApp channels',
              'Lead management with CSV import',
              'Response tracking & analytics',
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-brand-50">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-white/20">
                  <svg className="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </div>
                {item}
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-2xl bg-white/10 backdrop-blur-md p-6 border border-white/10">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 text-sm font-semibold">
                MR
              </div>
              <div>
                <p className="text-sm font-semibold">Maya Rodriguez</p>
                <p className="text-xs text-brand-50/70">Freelance Designer</p>
              </div>
            </div>
            <p className="mt-3 text-sm text-brand-50/90">
              "I went from sending 5 cold emails a day to 50. Landed two new clients in the first week."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
