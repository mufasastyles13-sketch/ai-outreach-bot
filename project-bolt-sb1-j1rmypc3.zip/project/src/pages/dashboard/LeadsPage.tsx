import { useState, useRef, useMemo } from 'react';
import { Plus, Upload, Search, Tag, Users, Trash2, Mail, Phone, Building2, Briefcase, FileText, Check, Filter } from 'lucide-react';
import { useLeads } from '../../lib/hooks';
import { parseCSV } from '../../lib/generator';
import { Modal, Button, Badge, EmptyState } from '../../components/ui';
import type { Lead, LeadStatus } from '../../lib/supabase';

const statusOptions: { value: LeadStatus; label: string; color: 'blue' | 'amber' | 'green' | 'slate' }[] = [
  { value: 'new', label: 'New', color: 'blue' },
  { value: 'contacted', label: 'Contacted', color: 'amber' },
  { value: 'responded', label: 'Responded', color: 'green' },
  { value: 'closed', label: 'Closed', color: 'slate' },
];

const statusBadge: Record<LeadStatus, { color: 'blue' | 'amber' | 'green' | 'slate'; label: string }> = {
  new: { color: 'blue', label: 'New' },
  contacted: { color: 'amber', label: 'Contacted' },
  responded: { color: 'green', label: 'Responded' },
  closed: { color: 'slate', label: 'Closed' },
};

export function LeadsPage() {
  const { leads, loading, addLead, addLeadsBatch, updateLead, deleteLead } = useLeads();
  const [showAddModal, setShowAddModal] = useState(false);
  const [showCsvModal, setShowCsvModal] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<LeadStatus | 'all'>('all');
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  const allTags = useMemo(() => {
    const tagSet = new Set<string>();
    leads.forEach((l) => l.tags?.forEach((t) => tagSet.add(t)));
    return Array.from(tagSet).sort();
  }, [leads]);

  const filteredLeads = useMemo(() => {
    return leads.filter((lead) => {
      const matchesSearch = !search ||
        lead.name.toLowerCase().includes(search.toLowerCase()) ||
        lead.email?.toLowerCase().includes(search.toLowerCase()) ||
        lead.company?.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
      const matchesTag = !tagFilter || lead.tags?.includes(tagFilter);
      return matchesSearch && matchesStatus && matchesTag;
    });
  }, [leads, search, statusFilter, tagFilter]);

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Leads</h1>
          <p className="mt-1 text-sm text-slate-500">Manage your prospects with tags, filters, and status tracking.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setShowCsvModal(true)} className="btn-secondary">
            <Upload className="h-4 w-4" /> Import CSV
          </button>
          <button onClick={() => setShowAddModal(true)} className="btn-primary">
            <Plus className="h-4 w-4" /> Add Lead
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by name, email, or company..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input-field pl-10"
            />
          </div>

          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-slate-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as LeadStatus | 'all')}
              className="rounded-lg border border-slate-200 bg-white px-3 py-2.5 text-sm text-slate-700 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/20"
            >
              <option value="all">All statuses</option>
              {statusOptions.map((s) => (
                <option key={s.value} value={s.value}>{s.label}</option>
              ))}
            </select>
          </div>
        </div>

        {allTags.length > 0 && (
          <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3">
            <span className="text-xs font-medium text-slate-400">Tags:</span>
            <button
              onClick={() => setTagFilter(null)}
              className={`tag-badge transition ${!tagFilter ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
            >
              All
            </button>
            {allTags.map((tag) => (
              <button
                key={tag}
                onClick={() => setTagFilter(tagFilter === tag ? null : tag)}
                className={`tag-badge transition ${tagFilter === tag ? 'bg-brand-100 text-brand-700' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                <Tag className="h-3 w-3" /> {tag}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Leads table */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="space-y-2 p-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-16 rounded-lg shimmer-bg animate-shimmer" />
            ))}
          </div>
        ) : filteredLeads.length === 0 ? (
          <EmptyState
            icon={<Users className="h-8 w-8" />}
            title={leads.length === 0 ? 'No leads yet' : 'No leads match your filters'}
            description={leads.length === 0
              ? 'Add leads manually or import a CSV to start your outreach campaign.'
              : 'Try adjusting your search or filters.'}
            action={leads.length === 0 ? (
              <div className="flex gap-2">
                <button onClick={() => setShowAddModal(true)} className="btn-primary">
                  <Plus className="h-4 w-4" /> Add Lead
                </button>
                <button onClick={() => setShowCsvModal(true)} className="btn-secondary">
                  <Upload className="h-4 w-4" /> Import CSV
                </button>
              </div>
            ) : (
              <button
                onClick={() => { setSearch(''); setStatusFilter('all'); setTagFilter(null); }}
                className="btn-secondary"
              >
                Clear filters
              </button>
            )}
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-100 bg-slate-50/50 text-left text-xs font-semibold uppercase tracking-wider text-slate-400">
                    <th className="px-4 py-3">Name</th>
                    <th className="hidden md:table-cell px-4 py-3">Company</th>
                    <th className="hidden lg:table-cell px-4 py-3">Industry</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="hidden md:table-cell px-4 py-3">Tags</th>
                    <th className="px-4 py-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {filteredLeads.map((lead) => (
                    <tr
                      key={lead.id}
                      className="cursor-pointer transition hover:bg-slate-50/50"
                      onClick={() => setSelectedLead(lead)}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-brand-100 to-accent-100 text-xs font-semibold text-brand-700">
                            {lead.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                          </div>
                          <div>
                            <p className="text-sm font-medium text-slate-900">{lead.name}</p>
                            {lead.email && <p className="text-xs text-slate-400">{lead.email}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="hidden md:table-cell px-4 py-3">
                        <p className="text-sm text-slate-700">{lead.company || '—'}</p>
                        {lead.role && <p className="text-xs text-slate-400">{lead.role}</p>}
                      </td>
                      <td className="hidden lg:table-cell px-4 py-3">
                        <p className="text-sm text-slate-700">{lead.industry || '—'}</p>
                      </td>
                      <td className="px-4 py-3">
                        <Badge color={statusBadge[lead.status].color}>
                          {statusBadge[lead.status].label}
                        </Badge>
                      </td>
                      <td className="hidden md:table-cell px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {lead.tags?.length > 0 ? lead.tags.slice(0, 3).map((tag) => (
                            <span key={tag} className="tag-badge bg-slate-100 text-slate-600">
                              <Tag className="h-2.5 w-2.5" /> {tag}
                            </span>
                          )) : <span className="text-xs text-slate-300">—</span>}
                          {lead.tags.length > 3 && (
                            <span className="text-xs text-slate-400">+{lead.tags.length - 3}</span>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => {
                            if (confirm(`Delete lead "${lead.name}"? This will also delete all messages for this lead.`)) {
                              deleteLead(lead.id);
                            }
                          }}
                          className="rounded-lg p-1.5 text-slate-400 transition hover:bg-red-50 hover:text-red-500"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="border-t border-slate-100 px-4 py-3 text-xs text-slate-400">
              Showing {filteredLeads.length} of {leads.length} leads
            </div>
          </>
        )}
      </div>

      <AddLeadModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={async (data) => { await addLead(data); setShowAddModal(false); }}
      />
      <CsvImportModal
        open={showCsvModal}
        onClose={() => setShowCsvModal(false)}
        onImport={async (data) => { await addLeadsBatch(data); setShowCsvModal(false); }}
      />
      {selectedLead && (
        <LeadDetailModal
          lead={selectedLead}
          onClose={() => setSelectedLead(null)}
          onUpdate={async (id, updates) => { await updateLead(id, updates); setSelectedLead((prev) => prev ? { ...prev, ...updates } : null); }}
        />
      )}
    </div>
  );
}

function AddLeadModal({ open, onClose, onAdd }: {
  open: boolean;
  onClose: () => void;
  onAdd: (data: Partial<Lead>) => Promise<void>;
}) {
  const [form, setForm] = useState({
    name: '', email: '', phone: '', company: '', role: '', industry: '', notes: '', tags: '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    setSaving(true);
    setError(null);
    try {
      await onAdd({
        name: form.name.trim(),
        email: form.email.trim() || null,
        phone: form.phone.trim() || null,
        company: form.company.trim() || null,
        role: form.role.trim() || null,
        industry: form.industry.trim() || null,
        notes: form.notes.trim() || null,
        tags: form.tags.split(',').map((t) => t.trim()).filter(Boolean),
      });
      setForm({ name: '', email: '', phone: '', company: '', role: '', industry: '', notes: '', tags: '' });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title="Add New Lead" size="lg">
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Name *</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input-field" placeholder="Jane Smith" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
            <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="input-field" placeholder="jane@company.com" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Phone / WhatsApp</label>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input-field" placeholder="+1 555 012 3456" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Company</label>
            <input value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} className="input-field" placeholder="Acme Inc." />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Role / Title</label>
            <input value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className="input-field" placeholder="VP of Marketing" />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium text-slate-700">Industry</label>
            <input value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })} className="input-field" placeholder="SaaS, E-commerce..." />
          </div>
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Notes</label>
          <textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="input-field resize-none" placeholder="Context about this lead..." />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Tags (comma-separated)</label>
          <input value={form.tags} onChange={(e) => setForm({ ...form, tags: e.target.value })} className="input-field" placeholder="priority, enterprise, warm" />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button type="submit" loading={saving}><Plus className="h-4 w-4" /> Add Lead</Button>
        </div>
      </form>
    </Modal>
  );
}

function CsvImportModal({ open, onClose, onImport }: {
  open: boolean;
  onClose: () => void;
  onImport: (data: Partial<Lead>[]) => Promise<void>;
}) {
  const [csvText, setCsvText] = useState('');
  const [parsed, setParsed] = useState<Partial<Lead>[]>([]);
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const text = ev.target?.result as string;
      setCsvText(text);
      setParsed(parseCSV(text));
    };
    reader.readAsText(file);
  };

  const handleParse = () => {
    setParsed(parseCSV(csvText));
  };

  const handleImport = async () => {
    if (parsed.length === 0) return;
    setImporting(true);
    setError(null);
    try {
      await onImport(parsed);
      setCsvText('');
      setParsed([]);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setImporting(false);
    }
  };

  const downloadTemplate = () => {
    const template = 'name,email,phone,company,role,industry,notes,tags\nJane Smith,jane@acme.com,+1 555 0100,Acme Inc,VP Marketing,SaaS,Looking for outreach tools,priority;enterprise\n';
    const blob = new Blob([template], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'lead-template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Modal open={open} onClose={onClose} title="Import Leads from CSV" size="lg">
      <div className="space-y-4">
        {error && <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-2 text-sm text-red-700">{error}</div>}

        <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-6 text-center">
          <Upload className="mx-auto h-8 w-8 text-slate-400" />
          <p className="mt-2 text-sm text-slate-600">Drag and drop or click to upload a CSV file</p>
          <input ref={fileRef} type="file" accept=".csv" onChange={handleFile} className="hidden" />
          <button onClick={() => fileRef.current?.click()} className="btn-secondary mt-3 text-xs">
            Choose File
          </button>
        </div>

        <div className="text-center text-xs text-slate-400">or paste CSV data below</div>

        <textarea
          rows={4}
          value={csvText}
          onChange={(e) => setCsvText(e.target.value)}
          className="input-field resize-none font-mono text-xs"
          placeholder="name,email,phone,company,role,industry,notes,tags&#10;Jane Smith,jane@acme.com,..."
        />

        <div className="flex items-center justify-between">
          <button onClick={downloadTemplate} className="text-sm font-medium text-brand-600 hover:text-brand-700">
            Download template
          </button>
          <button onClick={handleParse} className="btn-secondary text-sm" disabled={!csvText.trim()}>
            Parse CSV
          </button>
        </div>

        {parsed.length > 0 && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-4 animate-fade-in">
            <div className="flex items-center gap-2 text-sm font-medium text-green-700">
              <Check className="h-4 w-4" /> {parsed.length} leads ready to import
            </div>
            <div className="mt-2 max-h-32 overflow-y-auto scrollbar-thin">
              {parsed.map((lead, i) => (
                <div key={i} className="text-xs text-green-700">
                  {lead.name} {lead.company && `— ${lead.company}`}
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button onClick={handleImport} loading={importing} disabled={parsed.length === 0}>
            <Upload className="h-4 w-4" /> Import {parsed.length > 0 && `(${parsed.length})`}
          </Button>
        </div>
      </div>
    </Modal>
  );
}

function LeadDetailModal({ lead, onClose, onUpdate }: {
  lead: Lead;
  onClose: () => void;
  onUpdate: (id: string, updates: Partial<Lead>) => Promise<void>;
}) {
  const [status, setStatus] = useState<LeadStatus>(lead.status);
  const [tags, setTags] = useState(lead.tags.join(', '));
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onUpdate(lead.id, {
      status,
      tags: tags.split(',').map((t) => t.trim()).filter(Boolean),
    });
    setSaving(false);
  };

  return (
    <Modal open={true} onClose={onClose} title={lead.name} size="md">
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2">
          {lead.email && (
            <div className="flex items-center gap-2 text-sm">
              <Mail className="h-4 w-4 text-slate-400" />
              <a href={`mailto:${lead.email}`} className="text-brand-600 hover:underline">{lead.email}</a>
            </div>
          )}
          {lead.phone && (
            <div className="flex items-center gap-2 text-sm">
              <Phone className="h-4 w-4 text-slate-400" />
              <span className="text-slate-700">{lead.phone}</span>
            </div>
          )}
          {lead.company && (
            <div className="flex items-center gap-2 text-sm">
              <Building2 className="h-4 w-4 text-slate-400" />
              <span className="text-slate-700">{lead.company}</span>
            </div>
          )}
          {lead.role && (
            <div className="flex items-center gap-2 text-sm">
              <Briefcase className="h-4 w-4 text-slate-400" />
              <span className="text-slate-700">{lead.role}</span>
            </div>
          )}
          {lead.industry && (
            <div className="flex items-center gap-2 text-sm">
              <Tag className="h-4 w-4 text-slate-400" />
              <span className="text-slate-700">{lead.industry}</span>
            </div>
          )}
        </div>

        {lead.notes && (
          <div className="rounded-lg bg-slate-50 p-3">
            <div className="flex items-start gap-2">
              <FileText className="h-4 w-4 mt-0.5 text-slate-400 flex-shrink-0" />
              <p className="text-sm text-slate-600">{lead.notes}</p>
            </div>
          </div>
        )}

        <div className="border-t border-slate-100 pt-4">
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Status</label>
          <div className="flex gap-2">
            {statusOptions.map((s) => (
              <button
                key={s.value}
                onClick={() => setStatus(s.value)}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                  status === s.value
                    ? 'bg-brand-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Tags (comma-separated)</label>
          <input value={tags} onChange={(e) => setTags(e.target.value)} className="input-field" placeholder="priority, warm..." />
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="secondary" onClick={onClose}>Close</Button>
          <Button onClick={handleSave} loading={saving}><Check className="h-4 w-4" /> Save Changes</Button>
        </div>
      </div>
    </Modal>
  );
}
