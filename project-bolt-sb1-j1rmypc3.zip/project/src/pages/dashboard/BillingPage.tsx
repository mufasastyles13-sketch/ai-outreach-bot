import { CreditCard, Check, Sparkles, Zap, Crown, ArrowRight, Lock } from 'lucide-react';

export function BillingPage() {
  const plans = [
    {
      icon: Sparkles,
      name: 'Free',
      price: '$0',
      period: '/month',
      desc: 'Currently active on your account',
      features: ['Up to 25 leads', '10 AI messages/month', 'Email channel only', 'CSV import', 'Basic tagging'],
      current: true,
    },
    {
      icon: Zap,
      name: 'Pro',
      price: '$29',
      period: '/month',
      desc: 'For freelancers and small teams',
      features: ['1,000 leads', 'Unlimited AI messages', 'Email + WhatsApp', 'Advanced filtering', 'Response analytics', 'Priority support'],
      current: false,
      highlighted: true,
    },
    {
      icon: Crown,
      name: 'Business',
      price: '$99',
      period: '/month',
      desc: 'For agencies and startups',
      features: ['Unlimited leads', 'All channels + API', 'Team (5 seats)', 'Automated follow-ups', 'Custom templates', 'Account manager'],
      current: false,
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Billing & Plans</h1>
        <p className="mt-1 text-sm text-slate-500">Upgrade to unlock more leads, channels, and AI messages.</p>
      </div>

      {/* Current plan banner */}
      <div className="rounded-2xl border border-brand-200 bg-gradient-to-r from-brand-50 to-accent-50 p-6">
        <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-brand-600 to-accent-600 text-white">
              <Sparkles className="h-6 w-6" />
            </div>
            <div>
              <p className="font-semibold text-slate-900">You're on the Free Plan</p>
              <p className="text-sm text-slate-600">Enjoy full MVP access at no cost during development.</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="tag-badge bg-green-50 text-green-700">
              <Check className="h-3 w-3" /> Active
            </span>
          </div>
        </div>
      </div>

      {/* Plans grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {plans.map((plan, i) => (
          <div
            key={i}
            className={`relative card p-6 transition-all ${
              plan.highlighted ? 'ring-2 ring-brand-500' : ''
            }`}
          >
            {plan.highlighted && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-brand-600 to-accent-600 px-3 py-1 text-xs font-semibold text-white shadow-md">
                  <Sparkles className="h-3 w-3" /> Recommended
                </span>
              </div>
            )}

            <div className="flex items-center gap-3">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                plan.highlighted ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600'
              }`}>
                <plan.icon className="h-5 w-5" />
              </div>
              <div>
                <h3 className="font-bold text-slate-900">{plan.name}</h3>
                {plan.current && <span className="text-xs text-green-600">Your current plan</span>}
              </div>
            </div>

            <div className="mt-4 flex items-baseline gap-1">
              <span className="text-3xl font-extrabold text-slate-900">{plan.price}</span>
              <span className="text-sm text-slate-500">{plan.period}</span>
            </div>
            <p className="mt-1 text-sm text-slate-500">{plan.desc}</p>

            <ul className="mt-4 space-y-2">
              {plan.features.map((f, j) => (
                <li key={j} className="flex items-start gap-2 text-sm text-slate-700">
                  <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-green-500" />
                  {f}
                </li>
              ))}
            </ul>

            <button
              disabled={plan.current}
              className={`mt-6 w-full rounded-lg px-4 py-2.5 text-sm font-semibold transition ${
                plan.current
                  ? 'cursor-default bg-slate-100 text-slate-400'
                  : plan.highlighted
                  ? 'bg-brand-600 text-white hover:bg-brand-700'
                  : 'border border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              {plan.current ? 'Current Plan' : 'Upgrade'}
            </button>
          </div>
        ))}
      </div>

      {/* Stripe placeholder */}
      <div className="card overflow-hidden">
        <div className="border-b border-slate-100 p-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
              <CreditCard className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-semibold text-slate-900">Payment Method</h2>
              <p className="text-sm text-slate-500">Stripe integration is planned for the full release.</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center py-12 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-slate-100 text-slate-300">
            <Lock className="h-8 w-8" />
          </div>
          <h3 className="mt-4 font-semibold text-slate-900">Stripe Integration Coming Soon</h3>
          <p className="mt-2 max-w-md text-sm text-slate-500">
            The MVP runs free during development. Paid plans and Stripe checkout will be available
            once the full product launches with Gmail and WhatsApp API integration.
          </p>
          <div className="mt-4 flex items-center gap-2 text-xs text-slate-400">
            <span className="tag-badge bg-amber-50 text-amber-700">Planned</span>
            <span className="tag-badge bg-slate-100 text-slate-600">Stripe / PayPal</span>
          </div>
        </div>
      </div>

      {/* Billing history placeholder */}
      <div className="card p-6">
        <h2 className="font-semibold text-slate-900">Billing History</h2>
        <p className="mt-1 text-sm text-slate-500">No invoices yet — you're on the free plan.</p>
        <div className="mt-4 rounded-lg border border-dashed border-slate-200 p-8 text-center">
          <p className="text-sm text-slate-400">Invoices will appear here once you upgrade to a paid plan.</p>
        </div>
      </div>

      {/* CTA */}
      <div className="rounded-2xl bg-gradient-to-r from-brand-600 to-accent-600 p-8 text-center">
        <h2 className="text-xl font-bold text-white">Ready to scale your outreach?</h2>
        <p className="mt-2 text-sm text-brand-50">
          Keep using the free MVP — your data is safe and will carry over when paid plans launch.
        </p>
        <a href="#/app/leads" className="mt-4 inline-flex items-center gap-2 rounded-lg bg-white px-5 py-2.5 text-sm font-semibold text-brand-600 transition hover:scale-105">
          Go to Leads <ArrowRight className="h-4 w-4" />
        </a>
      </div>
    </div>
  );
}
