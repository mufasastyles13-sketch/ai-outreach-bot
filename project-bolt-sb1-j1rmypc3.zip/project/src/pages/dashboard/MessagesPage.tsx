import { useState, useMemo } from 'react';
import { Sparkles, Mail, MessageCircle, Send, Copy, Check, RefreshCw, Save, Users, ChevronDown, ChevronRight, Search } from 'lucide-react';
import { useLeads, useMessages } from '../../lib/hooks';
import { generateMessage } from '../../lib/generator';
import { Button, Badge, EmptyState, Modal } from '../../components/ui';
import type { Channel, Tone, Message } from '../../lib/supabase';

const tones: { value: Tone; label: string; desc: string }[] = [
  { value: 'friendly', label: 'Friendly', desc: 'Warm and conversational' },
  { value: 'formal', label: 'Formal', desc: 'Professional and respectful' },
  { value: 'concise', label: 'Concise', desc: 'Short and to the point' },
  { value: 'persuasive', label: 'Persuasive', desc: 'Compelling and action-oriented' },
];

const statusBadgeMap: Record<string, { color: 'slate' | 'blue' | 'green'; label: string }> = {
  draft: { color: 'slate', label: 'Draft' },
  sent: { color: 'blue', label: 'Sent' },
  replied: { color: 'green', label: 'Replied' },
};

export function MessagesPage() {
  const { leads, loading: leadsLoading } = useLeads();
  const { messages, loading: messagesLoading, addMessage, updateMessage, deleteMessage } = useMessages();

  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [channel, setChannel] = useState<Channel>('email');
  const [tone, setTone] = useState<Tone>('friendly');
  const [goal, setGoal] = useState('');
  const [generated, setGenerated] = useState<{ subject: string | null; body: string } | null>(null);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);
  const [search, setSearch] = useState('');
  const [showLeadList, setShowLeadList] = useState(true);
  const [viewMessage, setViewMessage] = useState<Message | null>(null);

  const selectedLead = useMemo(() => leads.find((l) => l.id === selectedLeadId) ?? null, [leads, selectedLeadId]);

  const filteredLeads = useMemo(() => {
    if (!search) return leads;
    return leads.filter((l) =>
      l.name.toLowerCase().includes(search.toLowerCase()) ||
      l.company?.toLowerCase().includes(search.toLowerCase())
    );
  }, [leads, search]);

  const handleGenerate = () => {
    if (!selectedLead) return;
    setGenerating(true);
    setTimeout(() => {
      const result = generateMessage({
        lead: selectedLead,
        channel,
        tone,
        goal: goal.trim() || undefined,
      });
      setGenerated(result);
      setGenerating(false);
    }, 800);
  };

  const handleCopy = () => {
    if (!generated) return;
    const text = generated.subject ? `Subject: ${generated.subject}\n\n${generated.body}` : generated.body;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSaveDraft = async () => {
    if (!generated || !selectedLead) return;
    setSaving(true);
    try {
      await addMessage({
        lead_id: selectedLead.id,
        channel,
        subject: generated.subject,
        body: generated.body,
        tone,
        goal: goal.trim() || null,
        status: 'draft',
      });
      setGenerated(null);
      setGoal('');
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  const handleSend = async () => {
    if (!generated || !selectedLead) return;
    setSending(true);
    try {
      await addMessage({
        lead_id: selectedLead.id,
        channel,
        subject: generated.subject,
        body: generated.body,
        tone,
        goal: goal.trim() || null,
        status: 'sent',
      });
      setGenerated(null);
      setGoal('');
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  const handleMarkReplied = async (id: string) => {
    await updateMessage(id, { status: 'replied' });
    setViewMessage(null);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">Messages</h1>
        <p className="mt-1 text-sm text-slate-500">Generate AI-powered outreach messages and track their status.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
        {/* Lead selector */}
        <div className="card overflow-hidden h-fit">
          <button
            onClick={() => setShowLeadList(!showLeadList)}
            className="flex w-full items-center justify-between border-b border-slate-100 p-4"
          >
            <span className="flex items-center gap-2 font-semibold text-slate-900">
              <Users className="h-4 w-4" /> Select Lead
            </span>
            {showLeadList ? <ChevronDown className="h-4 w-4 text-slate-400" /> : <ChevronRight className="h-4 w-4 text-slate-400" />}
          </button>

          {showLeadList && (
            <div className="p-3">
              <div className="relative mb-3">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search leads..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="input-field pl-10 text-sm"
                />
              </div>

              {leadsLoading ? (
                <div className="space-y-2">
                  {[...Array(4)].map((_, i) => (
                    <div key={i} className="h-12 rounded-lg shimmer-bg animate-shimmer" />
                  ))}
                </div>
              ) : filteredLeads.length === 0 ? (
                <p className="py-6 text-center text-sm text-slate-400">
                  No leads found. <a href="#/app/leads" className="text-brand-600 hover:underline">Add leads</a>
                </p>
              ) : (
                <div className="max-h-96 space-y-1 overflow-y-auto scrollbar-thin">
                  {filteredLeads.map((lead) => (
                    <button
                      key={lead.id}
                      onClick={() => { setSelectedLeadId(lead.id); setGenerated(null); }}
                      className={`flex w-full items-center gap-3 rounded-lg p-2 text-left transition ${
                        selectedLeadId === lead.id ? 'bg-brand-50 ring-1 ring-brand-200' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-brand-100 to-accent-100 text-xs font-semibold text-brand-700">
                        {lead.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="truncate text-sm font-medium text-slate-900">{lead.name}</p>
                        <p className="truncate text-xs text-slate-400">{lead.company || 'No company'}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Generator + Preview */}
        <div className="space-y-6">
          {!selectedLead ? (
            <div className="card">
              <EmptyState
                icon={<Sparkles className="h-8 w-8" />}
                title="Select a lead to generate a message"
                description="Pick a lead from the left panel, then choose your channel and tone to generate a personalized outreach message."
              />
            </div>
          ) : (
            <>
              {/* Selected lead card */}
              <div className="card p-4">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-brand-100 to-accent-100 text-sm font-semibold text-brand-700">
                    {selectedLead.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-slate-900">{selectedLead.name}</p>
                    <p className="text-sm text-slate-400">
                      {selectedLead.company || 'No company'} {selectedLead.role && `· ${selectedLead.role}`}
                      {selectedLead.industry && `· ${selectedLead.industry}`}
                    </p>
                  </div>
                </div>
              </div>

              {/* Generator controls */}
              <div className="card p-6">
                <h3 className="mb-4 font-semibold text-slate-900">Message Settings</h3>

                <div className="space-y-4">
                  {/* Channel */}
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">Channel</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => { setChannel('email'); setGenerated(null); }}
                        className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm font-medium transition ${
                          channel === 'email'
                            ? 'border-brand-500 bg-brand-50 text-brand-700'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <Mail className="h-4 w-4" /> Email
                      </button>
                      <button
                        onClick={() => { setChannel('whatsapp'); setGenerated(null); }}
                        className={`flex items-center justify-center gap-2 rounded-lg border p-3 text-sm font-medium transition ${
                          channel === 'whatsapp'
                            ? 'border-accent-500 bg-accent-50 text-accent-700'
                            : 'border-slate-200 text-slate-600 hover:border-slate-300'
                        }`}
                      >
                        <MessageCircle className="h-4 w-4" /> WhatsApp
                      </button>
                    </div>
                  </div>

                  {/* Tone */}
                  <div>
                    <label className="mb-2 block text-sm font-medium text-slate-700">Tone</label>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      {tones.map((t) => (
                        <button
                          key={t.value}
                          onClick={() => { setTone(t.value); setGenerated(null); }}
                          className={`rounded-lg border p-3 text-center transition ${
                            tone === t.value
                              ? 'border-brand-500 bg-brand-50'
                              : 'border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          <p className={`text-sm font-medium ${tone === t.value ? 'text-brand-700' : 'text-slate-700'}`}>{t.label}</p>
                          <p className="mt-0.5 text-xs text-slate-400">{t.desc}</p>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Goal */}
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">Outreach Goal (optional)</label>
                    <input
                      value={goal}
                      onChange={(e) => setGoal(e.target.value)}
                      className="input-field"
                      placeholder="e.g., schedule a demo, pitch our services, get feedback"
                    />
                  </div>

                  <Button onClick={handleGenerate} loading={generating} disabled={!selectedLead} size="lg" className="w-full">
                    {!generating && <Sparkles className="h-5 w-5" />}
                    {generating ? 'Generating...' : 'Generate Message'}
                    {!generating && <RefreshCw className="h-4 w-4" />}
                  </Button>
                </div>
              </div>

              {/* Preview */}
              {generated && (
                <div className="card overflow-hidden animate-fade-in-up">
                  <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50/50 px-4 py-3">
                    <div className="flex items-center gap-2">
                      <Sparkles className="h-4 w-4 text-brand-500" />
                      <span className="text-sm font-semibold text-slate-900">Preview</span>
                      <Badge color="blue">AI Generated</Badge>
                    </div>
                    <button onClick={handleCopy} className="btn-ghost text-xs">
                      {copied ? <><Check className="h-3.5 w-3.5 text-green-500" /> Copied</> : <><Copy className="h-3.5 w-3.5" /> Copy</>}
                    </button>
                  </div>

                  <div className="p-6">
                    {generated.subject && (
                      <div className="mb-4 border-b border-slate-100 pb-4">
                        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Subject</p>
                        <p className="mt-1 text-sm font-medium text-slate-900">{generated.subject}</p>
                      </div>
                    )}
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Message</p>
                      <pre className="mt-2 whitespace-pre-wrap font-sans text-sm leading-relaxed text-slate-700">{generated.body}</pre>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2 border-t border-slate-100 bg-slate-50/50 p-4 sm:flex-row sm:justify-between">
                    <Button variant="secondary" onClick={handleSaveDraft} loading={saving}>
                      <Save className="h-4 w-4" /> Save as Draft
                    </Button>
                    <Button onClick={handleSend} loading={sending}>
                      <Send className="h-4 w-4" /> Simulate Send
                    </Button>
                  </div>

                  <div className="border-t border-amber-100 bg-amber-50/50 px-4 py-2 text-center text-xs text-amber-700">
                    Preview mode — messages are saved but not sent live. Gmail & WhatsApp API integration is on the roadmap.
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Message history */}
      <div className="card overflow-hidden">
        <div className="border-b border-slate-100 p-4">
          <h2 className="font-semibold text-slate-900">Message History</h2>
        </div>

        {messagesLoading ? (
          <div className="space-y-2 p-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-20 rounded-lg shimmer-bg animate-shimmer" />
            ))}
          </div>
        ) : messages.length === 0 ? (
          <EmptyState
            icon={<MessageCircle className="h-8 w-8" />}
            title="No messages yet"
            description="Generate your first outreach message by selecting a lead above."
          />
        ) : (
          <div className="divide-y divide-slate-50">
            {messages.map((msg) => {
              const lead = leads.find((l) => l.id === msg.lead_id);
              return (
                <div
                  key={msg.id}
                  className="flex items-start gap-3 p-4 transition hover:bg-slate-50/50 cursor-pointer"
                  onClick={() => setViewMessage(msg)}
                >
                  <div className={`flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg ${
                    msg.channel === 'email' ? 'bg-brand-50 text-brand-600' : 'bg-accent-50 text-accent-600'
                  }`}>
                    {msg.channel === 'email' ? <Mail className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="truncate text-sm font-medium text-slate-900">
                        {msg.subject || 'WhatsApp message'}
                      </p>
                      <Badge color={statusBadgeMap[msg.status].color}>
                        {msg.status === 'sent' && <Send className="h-3 w-3" />}
                        {msg.status === 'replied' && <Check className="h-3 w-3" />}
                        {statusBadgeMap[msg.status].label}
                      </Badge>
                    </div>
                    <p className="mt-0.5 truncate text-xs text-slate-400">
                      To: {lead?.name ?? 'Unknown'} {lead?.company && `· ${lead.company}`}
                    </p>
                    <p className="mt-1 truncate text-xs text-slate-500">{msg.body.split('\n').slice(0, 2).join(' ')}...</p>
                  </div>
                  <span className="flex-shrink-0 text-xs text-slate-400">
                    {new Date(msg.created_at).toLocaleDateString()}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Message detail modal */}
      {viewMessage && (
        <Modal open={true} onClose={() => setViewMessage(null)} title="Message Details" size="lg">
          <MessageDetail
            message={viewMessage}
            leadName={leads.find((l) => l.id === viewMessage.lead_id)?.name ?? 'Unknown'}
            onMarkReplied={() => handleMarkReplied(viewMessage.id)}
            onDelete={async () => { await deleteMessage(viewMessage.id); setViewMessage(null); }}
          />
        </Modal>
      )}
    </div>
  );
}

function MessageDetail({ message, leadName, onMarkReplied, onDelete }: {
  message: Message;
  leadName: string;
  onMarkReplied: () => void;
  onDelete: () => Promise<void>;
}) {
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <Badge color={message.channel === 'email' ? 'blue' : 'teal'}>
          {message.channel === 'email' ? <Mail className="h-3 w-3" /> : <MessageCircle className="h-3 w-3" />}
          {message.channel}
        </Badge>
        <Badge color={statusBadgeMap[message.status].color}>{statusBadgeMap[message.status].label}</Badge>
        <Badge color="slate">Tone: {message.tone}</Badge>
      </div>

      <div className="rounded-lg bg-slate-50 p-3">
        <p className="text-xs text-slate-400">To</p>
        <p className="text-sm font-medium text-slate-900">{leadName}</p>
      </div>

      {message.subject && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Subject</p>
          <p className="mt-1 text-sm font-medium text-slate-900">{message.subject}</p>
        </div>
      )}

      <div>
        <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Body</p>
        <pre className="mt-2 whitespace-pre-wrap rounded-lg border border-slate-200 bg-white p-4 font-sans text-sm leading-relaxed text-slate-700">
          {message.body}
        </pre>
      </div>

      {message.goal && (
        <div>
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Goal</p>
          <p className="mt-1 text-sm text-slate-600">{message.goal}</p>
        </div>
      )}

      <p className="text-xs text-slate-400">
        Created: {new Date(message.created_at).toLocaleString()}
      </p>

      <div className="flex justify-between border-t border-slate-100 pt-4">
        <button
          onClick={() => { if (confirm('Delete this message?')) onDelete(); }}
          className="text-sm font-medium text-red-500 hover:text-red-600"
        >
          Delete
        </button>
        {message.status === 'sent' && (
          <Button onClick={onMarkReplied}>
            <Check className="h-4 w-4" /> Mark as Replied
          </Button>
        )}
      </div>
    </div>
  );
}
