import { Users, Mail, MessageCircle, TrendingUp, Send, Clock, CheckCircle2, ArrowRight, Plus, Sparkles } from 'lucide-react';
import { useLeads, useMessages } from '../../lib/hooks';
import type { LeadStatus } from '../../lib/supabase';

const statusColors: Record<LeadStatus, string> = {
  new: 'bg-blue-50 text-blue-700',
  contacted: 'bg-amber-50 text-amber-700',
  responded: 'bg-green-50 text-green-700',
  closed: 'bg-slate-100 text-slate-600',
};

export function OverviewPage() {
  const { leads, loading: leadsLoading } = useLeads();
  const { messages, loading: messagesLoading } = useMessages();

  const stats = {
    totalLeads: leads.length,
    newLeads: leads.filter((l) => l.status === 'new').length,
    totalMessages: messages.length,
    sentMessages: messages.filter((m) => m.status === 'sent').length,
    repliedMessages: messages.filter((m) => m.status === 'replied').length,
    emails: messages.filter((m) => m.channel === 'email').length,
    whatsapp: messages.filter((m) => m.channel === 'whatsapp').length,
  };

  const responseRate = stats.sentMessages > 0
    ? Math.round((stats.repliedMessages / stats.sentMessages) * 100)
    : 0;

  const recentLeads = leads.slice(0, 5);
  const recentMessages = messages.slice(0, 5);

  const statCards = [
    { label: 'Total Leads', value: stats.totalLeads, icon: Users, color: 'brand', sub: `${stats.newLeads} new` },
    { label: 'Messages Generated', value: stats.totalMessages, icon: Sparkles, color: 'accent', sub: `${stats.emails} emails · ${stats.whatsapp} WhatsApp` },
    { label: 'Messages Sent', value: stats.sentMessages, icon: Send, color: 'green', sub: 'Preview mode' },
    { label: 'Response Rate', value: `${responseRate}%`, icon: TrendingUp, color: 'amber', sub: `${stats.repliedMessages} replies` },
  ];

  const colorMap: Record<string, string> = {
    brand: 'from-brand-500 to-brand-600',
    accent: 'from-accent-500 to-accent-600',
    green: 'from-green-500 to-green-600',
    amber: 'from-amber-500 to-amber-600',
  };

  return (
    <div className="space-y-8 animate-fade-in">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Overview</h1>
          <p className="mt-1 text-sm text-slate-500">Track your outreach performance at a glance.</p>
        </div>
        <div className="flex gap-2">
          <a href="#/app/leads" className="btn-secondary">
            <Plus className="h-4 w-4" /> Add Lead
          </a>
          <a href="#/app/messages" className="btn-primary">
            <Sparkles className="h-4 w-4" /> Generate Message
          </a>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat, i) => (
          <div key={i} className="card p-5 animate-fade-in-up" style={{ animationDelay: `${i * 0.08}s` }}>
            <div className="flex items-center justify-between">
              <div className={`flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br ${colorMap[stat.color]} text-white`}>
                <stat.icon className="h-5 w-5" />
              </div>
            </div>
            <p className="mt-3 text-2xl font-bold text-slate-900">{leadsLoading && messagesLoading ? '—' : stat.value}</p>
            <p className="text-sm text-slate-500">{stat.label}</p>
            <p className="mt-1 text-xs text-slate-400">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Two-column section */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent leads */}
        <div className="card p-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h2 className="font-semibold text-slate-900">Recent Leads</h2>
            <a href="#/app/leads" className="flex items-center gap-1 text-sm font-medium text-brand-600 hover:text-brand-700">
              View all <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>

          {leadsLoading ? (
            <div className="space-y-3 py-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 rounded-lg shimmer-bg animate-shimmer" />
              ))}
            </div>
          ) : recentLeads.length === 0 ? (
            <div className="py-12 text-center">
              <Users className="mx-auto h-10 w-10 text-slate-300" />
              <p className="mt-3 text-sm text-slate-500">No leads yet. Add your first lead to get started.</p>
              <a href="#/app/leads" className="btn-primary mt-4 text-xs">Add Lead</a>
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {recentLeads.map((lead) => (
                <div key={lead.id} className="flex items-center gap-3 py-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand-100 to-accent-100 text-sm font-semibold text-brand-700">
                    {lead.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-medium text-slate-900">{lead.name}</p>
                    <p className="truncate text-xs text-slate-400">
                      {lead.company || 'No company'} {lead.role && `· ${lead.role}`}
                    </p>
                  </div>
                  <span className={`tag-badge ${statusColors[lead.status]}`}>{lead.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent messages */}
        <div className="card p-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <h2 className="font-semibold text-slate-900">Recent Messages</h2>
            <a href="#/app/messages" className="flex items-center gap-1 text-sm font-medium text-brand-600 hover:text-brand-700">
              View all <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>

          {messagesLoading ? (
            <div className="space-y-3 py-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-16 rounded-lg shimmer-bg animate-shimmer" />
              ))}
            </div>
          ) : recentMessages.length === 0 ? (
            <div className="py-12 text-center">
              <MessageCircle className="mx-auto h-10 w-10 text-slate-300" />
              <p className="mt-3 text-sm text-slate-500">No messages yet. Generate your first outreach message.</p>
              <a href="#/app/messages" className="btn-primary mt-4 text-xs">Generate Message</a>
            </div>
          ) : (
            <div className="divide-y divide-slate-50">
              {recentMessages.map((msg) => (
                <div key={msg.id} className="flex items-center gap-3 py-3">
                  <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${
                    msg.channel === 'email' ? 'bg-brand-50 text-brand-600' : 'bg-accent-50 text-accent-600'
                  }`}>
                    {msg.channel === 'email' ? <Mail className="h-4 w-4" /> : <MessageCircle className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="truncate text-sm font-medium text-slate-900">
                      {msg.subject || 'WhatsApp message'}
                    </p>
                    <p className="truncate text-xs text-slate-400">
                      To: {(msg as any).leads?.name ?? 'Unknown'}
                    </p>
                  </div>
                  <span className={`tag-badge ${
                    msg.status === 'sent' ? 'bg-blue-50 text-blue-700' :
                    msg.status === 'replied' ? 'bg-green-50 text-green-700' :
                    'bg-slate-100 text-slate-600'
                  }`}>
                    {msg.status === 'sent' && <Send className="h-3 w-3" />}
                    {msg.status === 'replied' && <CheckCircle2 className="h-3 w-3" />}
                    {msg.status === 'draft' && <Clock className="h-3 w-3" />}
                    {msg.status}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Quick start CTA */}
      {stats.totalLeads === 0 && stats.totalMessages === 0 && (
        <div className="rounded-2xl border border-brand-200 bg-gradient-to-r from-brand-50 to-accent-50 p-8">
          <div className="flex flex-col items-center text-center sm:flex-row sm:text-left">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-brand-600 to-accent-600 text-white">
              <Sparkles className="h-7 w-7" />
            </div>
            <div className="mt-4 flex-1 sm:mt-0 sm:ml-6">
              <h3 className="text-lg font-bold text-slate-900">Get started in 3 steps</h3>
              <p className="mt-1 text-sm text-slate-600">
                Add a lead, generate a personalized message, and preview the send. It takes less than 2 minutes.
              </p>
            </div>
            <a href="#/app/leads" className="btn-primary mt-4 sm:mt-0 sm:ml-6">
              Add your first lead <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      )}
    </div>
  );
}
