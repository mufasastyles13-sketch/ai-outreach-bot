import { Zap, Users, Mail, MessageCircle, BarChart3, Tag, Upload, Send, Check, FileText, Bot } from 'lucide-react';

export function FeaturesPage() {
  const features = [
    {
      icon: Bot,
      title: 'AI Message Generation',
      desc: "Generate personalized cold emails and WhatsApp messages in seconds. The AI references each lead's company, role, industry, and notes to craft messages that feel hand-written.",
      points: ['4 tone options: friendly, formal, concise, persuasive', 'Custom outreach goals per message', 'Context-aware personalization', 'Subject line generation for emails'],
      color: 'brand',
    },
    {
      icon: Users,
      title: 'Lead Management',
      desc: 'A simple CRM built for speed. Add leads manually or import via CSV. Tag, filter, and organize prospects without the complexity of enterprise tools.',
      points: ['Manual entry and CSV import', 'CRM-style tagging system', 'Filter by status, tag, or industry', 'Track lead lifecycle: new → contacted → responded → closed'],
      color: 'accent',
    },
    {
      icon: Mail,
      title: 'Email & WhatsApp Channels',
      desc: 'One tool for every outreach channel. Generate and preview messages for both cold email and WhatsApp Business — no switching between apps.',
      points: ['Cold email with subject lines', 'WhatsApp message format', 'Channel-specific formatting', 'Unified message history per lead'],
      color: 'brand',
    },
    {
      icon: BarChart3,
      title: 'Response Tracking',
      desc: 'Know exactly where every lead stands. Track which messages are drafts, sent, or replied to. Never let a warm lead go cold.',
      points: ['Message status tracking (draft, sent, replied)', 'Lead status auto-updates', 'Dashboard analytics at a glance', 'Full message history per lead'],
      color: 'accent',
    },
    {
      icon: Upload,
      title: 'CSV Import',
      desc: "Have a list of prospects? Upload a CSV and we'll parse names, emails, phones, companies, roles, industries, notes, and tags automatically.",
      points: ['Smart column mapping', 'Supports common header names', 'Bulk import in one click', 'Tags parsed from semicolon-separated values'],
      color: 'brand',
    },
    {
      icon: Send,
      title: 'Send Simulation',
      desc: 'Preview every message before it goes out. The MVP runs in preview mode — full Gmail and WhatsApp Business API integration is on the roadmap.',
      points: ['Preview before send', 'Edit generated messages', 'Simulated send with status tracking', 'Ready for live API integration'],
      color: 'accent',
    },
  ];

  const colorMap: Record<string, string> = {
    brand: 'from-brand-500 to-brand-600',
    accent: 'from-accent-500 to-accent-600',
  };

  return (
    <>
      <section className="border-b border-slate-100 bg-gradient-to-b from-white to-brand-50/30 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-sm font-medium text-brand-700">
            <Zap className="h-4 w-4" /> Features
          </div>
          <h1 className="mt-6 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            Built to automate your <span className="gradient-text">entire outreach workflow</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            Every feature is designed to save you time and win more clients. From lead capture to message generation to response tracking.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 md:grid-cols-2">
            {features.map((feature, i) => (
              <div
                key={i}
                className="card p-8 transition-all hover:shadow-md animate-fade-in-up"
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${colorMap[feature.color]} text-white`}>
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-xl font-bold text-slate-900">{feature.title}</h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">{feature.desc}</p>
                <ul className="mt-4 space-y-2">
                  {feature.points.map((point, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-slate-700">
                      <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-green-500" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-900">What's on the roadmap</h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
              This MVP is 40% complete. Here's what's planned for the full release.
            </p>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[
              { icon: Mail, title: 'Gmail API Integration', desc: 'Send emails directly from the dashboard with live Gmail API integration.', status: 'Planned' },
              { icon: MessageCircle, title: 'WhatsApp Business API', desc: 'Send WhatsApp messages automatically through the official Business API.', status: 'Planned' },
              { icon: BarChart3, title: 'Analytics Dashboard', desc: 'Open rates, click rates, response rates, and A/B testing for messages.', status: 'Planned' },
              { icon: Tag, title: 'Advanced CRM Tagging', desc: 'Custom tag categories, auto-tagging rules, and saved filter views.', status: 'Planned' },
              { icon: FileText, title: 'Template Library', desc: 'Save and reuse message templates across campaigns and channels.', status: 'Planned' },
              { icon: Zap, title: 'Automated Follow-ups', desc: 'Schedule automatic follow-up messages based on lead response status.', status: 'Planned' },
            ].map((item, i) => (
              <div key={i} className="card p-6 opacity-90">
                <div className="flex items-center justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-slate-100 text-slate-500">
                    <item.icon className="h-5 w-5" />
                  </div>
                  <span className="tag-badge bg-amber-50 text-amber-700">{item.status}</span>
                </div>
                <h3 className="mt-4 font-semibold text-slate-900">{item.title}</h3>
                <p className="mt-1 text-sm text-slate-500">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
