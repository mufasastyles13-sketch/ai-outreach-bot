import { Send, Zap, Target, Mail, MessageCircle, BarChart3, ArrowRight, Check, Sparkles, Users, Clock, TrendingUp } from 'lucide-react';
import { useAuth } from '../../lib/auth';

export function HomePage() {
  const { user } = useAuth();

  return (
    <>
      <section className="relative overflow-hidden bg-gradient-to-b from-white via-brand-50/30 to-white">
        <div className="absolute inset-0 -z-10">
          <div className="absolute left-1/4 top-0 h-72 w-72 rounded-full bg-brand-200/40 blur-3xl animate-float" />
          <div className="absolute right-1/4 top-32 h-96 w-96 rounded-full bg-accent-200/30 blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:px-8 lg:py-28">
          <div className="text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-sm font-medium text-brand-700 animate-fade-in-up">
              <Sparkles className="h-4 w-4" />
              AI-powered outreach that actually converts
            </div>

            <h1 className="max-w-4xl mx-auto text-4xl font-extrabold leading-tight tracking-tight text-slate-900 sm:text-5xl lg:text-6xl animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
              Win clients faster with
              <span className="gradient-text"> personalized cold outreach</span>
              on autopilot
            </h1>

            <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
              Generate tailored cold emails and WhatsApp messages, organize leads, and track responses —
              all in one place. Built for freelancers, small businesses, and startups.
            </p>

            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row animate-fade-in-up" style={{ animationDelay: '0.3s' }}>
              <a href={user ? '#/app' : '#/signup'} className="btn-primary text-base px-7 py-3.5">
                {user ? 'Go to Dashboard' : 'Start Free — No Card Required'}
                <ArrowRight className="h-5 w-5" />
              </a>
              <a href="#/features" className="btn-secondary text-base px-7 py-3.5">
                Explore Features
              </a>
            </div>

            <div className="mt-12 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-sm text-slate-500 animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
              <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-500" /> Free during MVP</span>
              <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-500" /> No credit card</span>
              <span className="flex items-center gap-1.5"><Check className="h-4 w-4 text-green-500" /> Setup in 2 minutes</span>
            </div>
          </div>

          <div className="mt-16 max-w-5xl mx-auto animate-fade-in-up" style={{ animationDelay: '0.5s' }}>
            <div className="rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl shadow-brand-900/10">
              <div className="rounded-xl bg-slate-50 p-6">
                <div className="grid gap-4 md:grid-cols-3">
                  {[
                    { icon: Mail, label: 'Email Drafts', count: '1,247', color: 'brand' },
                    { icon: MessageCircle, label: 'WhatsApp Msgs', count: '892', color: 'accent' },
                    { icon: TrendingUp, label: 'Response Rate', count: '34%', color: 'green' },
                  ].map((stat, i) => (
                    <div key={i} className="rounded-lg bg-white p-4 shadow-sm">
                      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                        stat.color === 'brand' ? 'bg-brand-50 text-brand-600' :
                        stat.color === 'accent' ? 'bg-accent-50 text-accent-600' :
                        'bg-green-50 text-green-600'
                      }`}>
                        <stat.icon className="h-5 w-5" />
                      </div>
                      <p className="mt-3 text-2xl font-bold text-slate-900">{stat.count}</p>
                      <p className="text-sm text-slate-500">{stat.label}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-4 rounded-lg bg-white p-4 shadow-sm">
                  <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-brand-600">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-slate-900">AI generated email to Sarah Chen</p>
                      <p className="text-xs text-slate-400">VP Marketing at TechFlow Inc.</p>
                    </div>
                    <span className="tag-badge bg-green-50 text-green-700">Sent</span>
                  </div>
                  <div className="mt-3 space-y-2">
                    <p className="text-sm text-slate-700">Subject: Quick idea for TechFlow's Q4 campaigns</p>
                    <p className="text-sm text-slate-500 line-clamp-2">
                      Hi Sarah, I came across TechFlow and noticed you're scaling your marketing team.
                      I help SaaS companies like yours automate personalized outreach and cut response
                      time from days to minutes...
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-900 sm:text-4xl">Everything you need to land clients</h2>
            <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
              From lead capture to message generation to response tracking — OutreachAI handles the entire outreach workflow.
            </p>
          </div>

          <div className="mt-16 grid gap-8 md:grid-cols-3">
            {[
              { icon: Zap, title: 'AI Message Generation', desc: 'Generate personalized cold emails and WhatsApp messages in seconds. Choose tone, goal, and channel — the AI handles the rest.' },
              { icon: Users, title: 'Lead Management', desc: 'Import leads manually or via CSV. Tag, filter, and organize prospects with a simple CRM-style interface built for speed.' },
              { icon: Target, title: 'Smart Targeting', desc: "Context-aware messages that reference each lead's company, role, and industry. No more generic templates that get ignored." },
              { icon: Mail, title: 'Email & WhatsApp', desc: 'Support for both cold email and WhatsApp Business outreach. One tool, every channel your prospects actually use.' },
              { icon: BarChart3, title: 'Response Tracking', desc: 'Track which messages got sent, which got replies, and which leads are ready to close. Never lose track of a conversation.' },
              { icon: Clock, title: 'Save 10+ Hours/Week', desc: 'Stop writing outreach messages by hand. Automate the busywork and spend your time on what matters: closing deals.' },
            ].map((feature, i) => (
              <div
                key={i}
                className="group card p-6 transition-all hover:shadow-md hover:-translate-y-1 animate-fade-in-up"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-accent-500 text-white transition-transform group-hover:scale-110">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-4 text-lg font-semibold text-slate-900">{feature.title}</h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 sm:text-4xl">How it works</h2>
              <p className="mt-4 text-lg text-slate-600">
                Three simple steps from lead to sent message. No copy-pasting, no generic templates.
              </p>

              <div className="mt-8 space-y-6">
                {[
                  { step: '01', title: 'Add your leads', desc: 'Enter leads manually or upload a CSV with names, companies, roles, and industries.' },
                  { step: '02', title: 'Generate personalized messages', desc: 'Pick a channel (email or WhatsApp), set the tone, and let the AI craft a tailored message for each lead.' },
                  { step: '03', title: 'Preview and send', desc: 'Review each generated message, make edits if needed, and simulate sending. Track responses as they come in.' },
                ].map((item, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white">
                      {item.step}
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-slate-900">{item.title}</h3>
                      <p className="mt-1 text-sm text-slate-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-to-br from-brand-200/40 to-accent-200/40 blur-2xl" />
              <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-xl">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
                  <div className="flex gap-1.5">
                    <div className="h-3 w-3 rounded-full bg-red-400" />
                    <div className="h-3 w-3 rounded-full bg-amber-400" />
                    <div className="h-3 w-3 rounded-full bg-green-400" />
                  </div>
                  <span className="ml-2 text-sm text-slate-400">OutreachAI — Message Preview</span>
                </div>

                <div className="mt-4 space-y-3">
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs font-medium text-slate-500">To: David Park</p>
                    <p className="text-xs text-slate-400">Founder at ParkStudio Design</p>
                  </div>
                  <div className="rounded-lg bg-slate-50 p-3">
                    <p className="text-xs font-medium text-slate-500">Subject: Helping ParkStudio scale client outreach</p>
                  </div>
                  <div className="rounded-lg border border-brand-200 bg-brand-50/50 p-4">
                    <p className="text-sm text-slate-700">
                      Hi David,<br /><br />
                      I came across ParkStudio Design and love the work you're doing for creative agencies.
                      I help design studios like yours automate personalized outreach and win 3x more clients
                      without hiring a sales team.<br /><br />
                      Would you be open to a quick 15-minute chat this week?<br /><br />
                      Cheers,<br />
                      Alex
                    </p>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Sparkles className="h-3.5 w-3.5 text-brand-500" />
                      Generated in 2.3 seconds
                    </div>
                    <button className="btn-primary text-xs px-3 py-1.5">
                      <Send className="h-3 w-3" /> Send
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-slate-900 sm:text-4xl">Loved by freelancers and small teams</h2>
          </div>

          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { quote: 'I went from sending 5 cold emails a day to 50. Landed two new clients in the first week.', name: 'Maya Rodriguez', role: 'Freelance Designer' },
              { quote: 'The AI-generated messages feel personal, not robotic. My response rate jumped from 8% to 31%.', name: 'James Okafor', role: 'Founder, ByteForge' },
              { quote: "Finally a tool that doesn't require a CRM degree to use. Simple, fast, and it works.", name: 'Sophie Laurent', role: 'Marketing Consultant' },
            ].map((t, i) => (
              <div key={i} className="card p-6">
                <div className="flex gap-1 text-amber-400">
                  {[...Array(5)].map((_, j) => (
                    <svg key={j} className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="mt-4 text-sm text-slate-700 leading-relaxed">"{t.quote}"</p>
                <div className="mt-4 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-brand-400 to-accent-400 text-sm font-semibold text-white">
                    {t.name.split(' ').map((n) => n[0]).join('')}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">{t.name}</p>
                    <p className="text-xs text-slate-500">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-r from-brand-600 to-accent-600 py-16">
        <div className="mx-auto max-w-4xl px-4 text-center sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white sm:text-4xl">Ready to automate your outreach?</h2>
          <p className="mt-4 text-lg text-brand-50">
            Join the MVP today. Free during development — no credit card required.
          </p>
          <a href={user ? '#/app' : '#/signup'} className="mt-8 inline-flex items-center gap-2 rounded-lg bg-white px-7 py-3.5 text-base font-semibold text-brand-600 shadow-lg transition hover:shadow-xl hover:scale-[1.02]">
            {user ? 'Go to Dashboard' : 'Get Started Free'}
            <ArrowRight className="h-5 w-5" />
          </a>
        </div>
      </section>
    </>
  );
}
