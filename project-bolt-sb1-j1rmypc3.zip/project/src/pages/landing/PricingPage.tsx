import { Check, Sparkles, Zap, Crown } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../../lib/auth';

export function PricingPage() {
  const { user } = useAuth();
  const [annual, setAnnual] = useState(false);

  const plans = [
    {
      icon: Sparkles,
      name: 'Free',
      price: { monthly: 0, annual: 0 },
      desc: 'Perfect for trying out the MVP',
      features: [
        'Up to 25 leads',
        '10 AI-generated messages per month',
        'Email channel only',
        'CSV import',
        'Basic lead tagging',
        'Community support',
      ],
      cta: 'Start Free',
      href: user ? '#/app' : '#/signup',
      highlighted: false,
    },
    {
      icon: Zap,
      name: 'Pro',
      price: { monthly: 29, annual: 24 },
      desc: 'For freelancers and small teams',
      features: [
        'Up to 1,000 leads',
        'Unlimited AI-generated messages',
        'Email + WhatsApp channels',
        'CSV import + export',
        'Advanced tagging & filtering',
        'Response tracking & analytics',
        'Priority support',
      ],
      cta: 'Coming Soon',
      href: '#/pricing',
      highlighted: true,
      badge: 'Most Popular',
    },
    {
      icon: Crown,
      name: 'Business',
      price: { monthly: 99, annual: 79 },
      desc: 'For agencies and growing startups',
      features: [
        'Unlimited leads',
        'Unlimited AI messages',
        'All channels + API access',
        'Team collaboration (5 seats)',
        'Automated follow-ups',
        'Custom templates library',
        'Dedicated account manager',
      ],
      cta: 'Coming Soon',
      href: '#/pricing',
      highlighted: false,
    },
  ];

  return (
    <>
      <section className="border-b border-slate-100 bg-gradient-to-b from-white to-brand-50/30 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-brand-200 bg-brand-50 px-4 py-1.5 text-sm font-medium text-brand-700">
            <Sparkles className="h-4 w-4" /> Simple, transparent pricing
          </div>
          <h1 className="mt-6 text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            Choose the plan that <span className="gradient-text">fits your growth</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            The MVP is free during development. Paid plans launch with full Gmail and WhatsApp API integration.
          </p>

          <div className="mt-8 inline-flex items-center gap-3 rounded-full border border-slate-200 bg-white p-1 shadow-sm">
            <button
              onClick={() => setAnnual(false)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                !annual ? 'bg-brand-600 text-white' : 'text-slate-600'
              }`}
            >
              Monthly
            </button>
            <button
              onClick={() => setAnnual(true)}
              className={`rounded-full px-4 py-1.5 text-sm font-medium transition ${
                annual ? 'bg-brand-600 text-white' : 'text-slate-600'
              }`}
            >
              Annual
              <span className="ml-1.5 text-xs text-green-500">Save 20%</span>
            </button>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-8 lg:grid-cols-3">
            {plans.map((plan, i) => (
              <div
                key={i}
                className={`relative card p-8 transition-all animate-fade-in-up ${
                  plan.highlighted ? 'ring-2 ring-brand-500 shadow-lg lg:-translate-y-4' : 'hover:shadow-md'
                }`}
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <span className="inline-flex items-center gap-1 rounded-full bg-gradient-to-r from-brand-600 to-accent-600 px-4 py-1 text-xs font-semibold text-white shadow-md">
                      <Sparkles className="h-3 w-3" /> {plan.badge}
                    </span>
                  </div>
                )}

                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                    plan.highlighted ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}>
                    <plan.icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">{plan.name}</h3>
                </div>

                <p className="mt-2 text-sm text-slate-500">{plan.desc}</p>

                <div className="mt-6 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-slate-900">
                    ${annual ? plan.price.annual : plan.price.monthly}
                  </span>
                  <span className="text-sm text-slate-500">/month</span>
                </div>
                {annual && plan.price.annual > 0 && (
                  <p className="mt-1 text-xs text-green-600">Billed annually</p>
                )}

                <a
                  href={plan.href}
                  className={`mt-6 block w-full rounded-lg px-4 py-3 text-center text-sm font-semibold transition ${
                    plan.highlighted
                      ? 'bg-brand-600 text-white hover:bg-brand-700'
                      : plan.price.monthly === 0
                      ? 'bg-brand-600 text-white hover:bg-brand-700'
                      : 'border border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {plan.cta}
                </a>

                <ul className="mt-6 space-y-3">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-slate-700">
                      <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-green-500" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-12 rounded-xl border border-amber-200 bg-amber-50 p-6 text-center">
            <p className="text-sm text-amber-800">
              <strong>Note:</strong> The MVP is currently free for all users. Paid plans and Stripe integration
              are on the roadmap. No credit card required to get started.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-center text-2xl font-bold text-slate-900">Frequently asked questions</h2>
          <div className="mt-8 space-y-4">
            {[
              { q: 'Is the MVP really free?', a: 'Yes. During the MVP phase, all features are free with no credit card required. Paid plans will launch once Gmail and WhatsApp API integrations are complete.' },
              { q: 'When will paid plans launch?', a: 'Paid plans will launch alongside full API integrations (Gmail and WhatsApp Business). The Free tier will always remain available for small-scale use.' },
              { q: 'Do the AI messages feel personal?', a: "Yes. The generator references each lead's name, company, role, industry, and notes. You can choose from four tones and set a custom outreach goal per message." },
              { q: 'Can I import my existing leads?', a: "Absolutely. Upload a CSV with common headers (name, email, phone, company, role, industry, notes, tags) and we'll parse everything automatically." },
              { q: 'Does it send real emails?', a: 'Not yet. The MVP runs in preview/simulation mode. Full Gmail and WhatsApp Business API integration is the top priority on the roadmap.' },
            ].map((faq, i) => (
              <div key={i} className="card p-5">
                <h3 className="font-semibold text-slate-900">{faq.q}</h3>
                <p className="mt-2 text-sm text-slate-600">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
