import { useState } from 'react';
import { Mail, MessageCircle, MapPin, Send, Check } from 'lucide-react';

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <>
      <section className="border-b border-slate-100 bg-gradient-to-b from-white to-brand-50/30 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">
            Get in <span className="gradient-text">touch</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-slate-600">
            Questions about the MVP, the roadmap, or interested in acquiring the project? We'd love to hear from you.
          </p>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid gap-12 lg:grid-cols-2">
            <div>
              <h2 className="text-2xl font-bold text-slate-900">Let's talk</h2>
              <p className="mt-4 text-slate-600">
                Whether you're a freelancer looking to automate outreach, a business evaluating tools,
                or an investor interested in acquiring this SaaS project — reach out.
              </p>

              <div className="mt-8 space-y-4">
                {[
                  { icon: Mail, label: 'Email', value: 'hello@outreachai.com', href: 'mailto:hello@outreachai.com' },
                  { icon: MessageCircle, label: 'WhatsApp', value: '+1 (555) 012-3456', href: '#' },
                  { icon: MapPin, label: 'Location', value: 'Remote · Worldwide', href: null },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4 rounded-xl border border-slate-200 bg-white p-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                      <item.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-500">{item.label}</p>
                      {item.href ? (
                        <a href={item.href} className="text-sm font-semibold text-slate-900 hover:text-brand-600">
                          {item.value}
                        </a>
                      ) : (
                        <p className="text-sm font-semibold text-slate-900">{item.value}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 rounded-xl bg-gradient-to-r from-brand-50 to-accent-50 p-6">
                <h3 className="font-semibold text-slate-900">Interested in acquiring this project?</h3>
                <p className="mt-2 text-sm text-slate-600">
                  This MVP is 40% complete with a clear roadmap. Includes working demo, dashboard,
                  landing pages, and paywall placeholder. Mention "acquisition" in your message.
                </p>
              </div>
            </div>

            <div className="card p-8">
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-50 text-green-500">
                    <Check className="h-8 w-8" />
                  </div>
                  <h3 className="mt-4 text-xl font-bold text-slate-900">Message sent!</h3>
                  <p className="mt-2 text-sm text-slate-500">
                    Thanks for reaching out. We'll get back to you within 24 hours.
                  </p>
                  <button
                    onClick={() => { setSubmitted(false); setForm({ name: '', email: '', message: '' }); }}
                    className="btn-secondary mt-6"
                  >
                    Send another message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">Name</label>
                    <input
                      required
                      type="text"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="input-field"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">Email</label>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="input-field"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="mb-1.5 block text-sm font-medium text-slate-700">Message</label>
                    <textarea
                      required
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="input-field resize-none"
                      placeholder="Tell us what you need..."
                    />
                  </div>
                  <button type="submit" className="btn-primary w-full">
                    <Send className="h-4 w-4" /> Send Message
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
