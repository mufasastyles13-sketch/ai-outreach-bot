import { ReactNode, useState } from 'react';
import { Send, LayoutDashboard, Users, MessageSquare, CreditCard, LogOut, Menu, X, ExternalLink, Bell } from 'lucide-react';
import { useAuth } from '../lib/auth';

interface NavItem {
  label: string;
  icon: typeof LayoutDashboard;
  href: string;
  path: string;
}

const navItems: NavItem[] = [
  { label: 'Overview', icon: LayoutDashboard, href: '#/app', path: '/app' },
  { label: 'Leads', icon: Users, href: '#/app/leads', path: '/app/leads' },
  { label: 'Messages', icon: MessageSquare, href: '#/app/messages', path: '/app/messages' },
  { label: 'Billing', icon: CreditCard, href: '#/app/billing', path: '/app/billing' },
];

export function DashboardLayout({ children, currentPath }: { children: ReactNode; currentPath: string }) {
  const { user, signOut } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === '/app') return currentPath === '/app';
    return currentPath.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-30 bg-slate-900/40 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-40 w-64 bg-white border-r border-slate-200 transition-transform lg:translate-x-0 ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        <div className="flex h-16 items-center justify-between border-b border-slate-100 px-4">
          <a href="#/app" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-600 to-accent-600 text-white">
              <Send className="h-4 w-4" />
            </div>
            <span className="text-lg font-bold text-slate-900">OutreachAI</span>
          </a>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-slate-400">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex flex-col gap-1 p-3">
          {navItems.map((item) => (
            <a
              key={item.path}
              href={item.href}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition ${
                isActive(item.path)
                  ? 'bg-brand-50 text-brand-700'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}
            >
              <item.icon className="h-5 w-5" />
              {item.label}
            </a>
          ))}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 border-t border-slate-100 p-3">
          <div className="mb-2 flex items-center gap-3 rounded-lg p-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-brand-400 to-accent-400 text-sm font-semibold text-white">
              {user?.email?.[0]?.toUpperCase() ?? 'U'}
            </div>
            <div className="flex-1 overflow-hidden">
              <p className="truncate text-sm font-medium text-slate-700">{user?.email}</p>
              <p className="text-xs text-slate-400">Free Plan</p>
            </div>
          </div>
          <a href="#/" className="flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50">
            <ExternalLink className="h-4 w-4" />
            Back to site
          </a>
          <button
            onClick={() => signOut()}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            <LogOut className="h-4 w-4" />
            Sign out
          </button>
        </div>
      </aside>

      {/* Main content */}
      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 flex h-16 items-center justify-between border-b border-slate-200 bg-white/80 backdrop-blur-lg px-4 sm:px-6">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-600">
              <Menu className="h-5 w-5" />
            </button>
            <span className="text-sm text-slate-400">Dashboard</span>
          </div>

          <div className="flex items-center gap-3">
            <a href="#/app/billing" className="hidden sm:inline-flex">
              <span className="tag-badge bg-amber-50 text-amber-700">Free Plan</span>
            </a>
            <button className="relative rounded-lg p-2 text-slate-400 hover:bg-slate-100 hover:text-slate-600">
              <Bell className="h-5 w-5" />
              <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-brand-500" />
            </button>
          </div>
        </header>

        <main className="p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    </div>
  );
}
