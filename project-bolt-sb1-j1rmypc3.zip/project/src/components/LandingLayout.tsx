import { ReactNode, useState } from 'react';
import { Send, Menu, X } from 'lucide-react';
import { useAuth } from '../lib/auth';

interface NavLink {
  label: string;
  href: string;
}

const navLinks: NavLink[] = [
  { label: 'Home', href: '#/' },
  { label: 'Features', href: '#/features' },
  { label: 'Pricing', href: '#/pricing' },
  { label: 'Contact', href: '#/contact' },
];

export function LandingHeader({ currentPath }: { currentPath: string }) {
  const { user } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isActive = (href: string) => {
    const path = href.replace('#', '') || '/';
    return currentPath === path;
  };

  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/60 bg-white/80 backdrop-blur-lg">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="#/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-600 to-accent-600 text-white">
            <Send className="h-4 w-4" />
          </div>
          <span className="text-lg font-bold text-slate-900">Outreach<span className="text-brand-600">AI</span></span>
        </a>

        <nav className="hidden items-center gap-1 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className={`rounded-lg px-3 py-2 text-sm font-medium transition ${
                isActive(link.href)
                  ? 'text-brand-600 bg-brand-50'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <a href="#/app" className="btn-primary">
              Go to Dashboard
            </a>
          ) : (
            <>
              <a href="#/login" className="btn-ghost">Sign In</a>
              <a href="#/signup" className="btn-primary">Get Started Free</a>
            </>
          )}
        </div>

        <button
          className="rounded-lg p-2 text-slate-600 md:hidden"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {mobileOpen && (
        <div className="border-t border-slate-200 bg-white md:hidden">
          <div className="space-y-1 px-4 py-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className={`block rounded-lg px-3 py-2 text-sm font-medium ${
                  isActive(link.href) ? 'text-brand-600 bg-brand-50' : 'text-slate-600'
                }`}
              >
                {link.label}
              </a>
            ))}
            <div className="pt-2">
              {user ? (
                <a href="#/app" className="btn-primary w-full" onClick={() => setMobileOpen(false)}>
                  Go to Dashboard
                </a>
              ) : (
                <div className="flex gap-2">
                  <a href="#/login" className="btn-secondary flex-1" onClick={() => setMobileOpen(false)}>Sign In</a>
                  <a href="#/signup" className="btn-primary flex-1" onClick={() => setMobileOpen(false)}>Sign Up</a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

export function LandingFooter() {
  return (
    <footer className="border-t border-slate-200 bg-white">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-brand-600 to-accent-600 text-white">
                <Send className="h-4 w-4" />
              </div>
              <span className="text-lg font-bold text-slate-900">OutreachAI</span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-slate-500">
              AI-powered outreach automation for freelancers, small businesses, and startups.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Product</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#/features" className="text-slate-500 hover:text-brand-600">Features</a></li>
              <li><a href="#/pricing" className="text-slate-500 hover:text-brand-600">Pricing</a></li>
              <li><a href="#/app" className="text-slate-500 hover:text-brand-600">Dashboard</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Company</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#/" className="text-slate-500 hover:text-brand-600">About</a></li>
              <li><a href="#/contact" className="text-slate-500 hover:text-brand-600">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-slate-900">Legal</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li><a href="#/" className="text-slate-500 hover:text-brand-600">Privacy</a></li>
              <li><a href="#/" className="text-slate-500 hover:text-brand-600">Terms</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-10 flex flex-col items-center justify-between border-t border-slate-100 pt-6 sm:flex-row">
          <p className="text-sm text-slate-400">© 2025 OutreachAI. All rights reserved.</p>
          <p className="mt-2 text-sm text-slate-400 sm:mt-0">Built with Bolt AI</p>
        </div>
      </div>
    </footer>
  );
}

export function LandingLayout({ children, currentPath }: { children: ReactNode; currentPath: string }) {
  return (
    <div className="min-h-screen bg-white">
      <LandingHeader currentPath={currentPath} />
      <main>{children}</main>
      <LandingFooter />
    </div>
  );
}
