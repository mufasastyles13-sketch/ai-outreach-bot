import type { Lead, Channel, Tone } from './supabase';

interface GenerateParams {
  lead: Lead;
  channel: Channel;
  tone: Tone;
  goal?: string;
}

interface GeneratedMessage {
  subject: string | null;
  body: string;
}

const toneOpeners: Record<Tone, string[]> = {
  friendly: ['Hi {name},', 'Hey {name} —', 'Hello {name}!'],
  formal: ['Dear {name},', 'Good day {name},', 'Greetings {name},'],
  concise: ['{name},', 'Hi {name},'],
  persuasive: ['{name}, I noticed something about {company}.', 'Hi {name} — I have an idea for {company}.'],
};

const valueProps = [
  'streamline your operations',
  'scale your outreach without hiring more people',
  'save 10+ hours per week on manual follow-ups',
  'turn cold contacts into warm conversations',
  'automate the busywork so you can focus on closing deals',
  'cut your response time from days to minutes',
];

const ctas: Record<Tone, string[]> = {
  friendly: [
    'Would you be open to a quick 15-minute chat this week?',
    'Mind if I send over a short demo?',
    'Free for a quick call sometime soon?',
  ],
  formal: [
    'I would welcome the opportunity to discuss this further at your convenience.',
    'May I propose a brief introductory call to explore how we might collaborate?',
    'Would you be available for a short consultation this week?',
  ],
  concise: [
    'Open to a 15-min call?',
    'Can I send a quick demo?',
    'Worth a brief chat?',
  ],
  persuasive: [
    "If you're interested, I can show you exactly how this works in 15 minutes. Should I send a calendar link?",
    "I'm confident this can move the needle for {company}. Are you open to a quick call to see how?",
    "Let's turn this into a conversation. When works for a 15-minute demo?",
  ],
};

const closings: Record<Tone, string> = {
  friendly: 'Cheers,\n{senderName}',
  formal: 'Sincerely,\n{senderName}',
  concise: '— {senderName}',
  persuasive: 'Looking forward to it,\n{senderName}',
};

function pick<T>(arr: T[], seed: number): T {
  return arr[seed % arr.length];
}

function personalize(template: string, lead: Lead, senderName = 'Alex'): string {
  const replacements: Record<string, string> = {
    '{name}': lead.name.split(' ')[0] || lead.name,
    '{fullName}': lead.name,
    '{company}': lead.company || 'your company',
    '{role}': lead.role || 'your team',
    '{industry}': lead.industry || 'your industry',
    '{senderName}': senderName,
  };
  let result = template;
  for (const [key, val] of Object.entries(replacements)) {
    result = result.split(key).join(val);
  }
  return result;
}

export function generateMessage({ lead, channel, tone, goal }: GenerateParams): GeneratedMessage {
  const seed = lead.name.length + (lead.company?.length ?? 0) + tone.length;
  const opener = pick(toneOpeners[tone], seed);
  const valueProp = pick(valueProps, seed + 1);
  const cta = pick(ctas[tone], seed + 2);
  const closing = closings[tone];
  const goalLine = goal
    ? ` My goal is to ${goal.toLowerCase()}.`
    : '';

  if (channel === 'whatsapp') {
    const body = [
      personalize(opener, lead),
      '',
      `I help ${lead.industry ? `people in ${lead.industry}` : 'businesses like yours'} ${valueProp}.${goalLine}`,
      '',
      personalize(cta, lead),
    ].join('\n');
    return { subject: null, body };
  }

  const subjectLines = [
    `Quick idea for ${lead.company || lead.name}`,
    `Helping ${lead.company || 'you'} ${valueProp.split(' ').slice(0, 3).join(' ')}`,
    `${lead.name}, a question about ${lead.industry || 'your work'}`,
    `Worth 15 minutes? (${lead.company || 'your team'})`,
  ];

  const body = [
    personalize(opener, lead),
    '',
    `I came across ${lead.company || 'your work'}${lead.role ? ` and noticed you're working as ${lead.role}` : ''}. I help ${lead.industry ? `teams in ${lead.industry}` : 'businesses like yours'} ${valueProp}.${goalLine}`,
    '',
    lead.notes
      ? `I saw that ${lead.notes.toLowerCase().replace(/\.$/, '')}. This is exactly the kind of challenge I work on.`
      : `This is the kind of challenge I help with regularly.`,
    '',
    personalize(cta, lead),
    '',
    personalize(closing, lead),
  ].join('\n');

  return {
    subject: personalize(pick(subjectLines, seed), lead),
    body,
  };
}

export function parseCSV(text: string): Partial<Lead>[] {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];

  const headers = lines[0].split(',').map((h) => h.trim().toLowerCase());
  const results: Partial<Lead>[] = [];

  for (let i = 1; i < lines.length; i++) {
    const values = parseCSVLine(lines[i]);
    if (values.length === 0) continue;

    const row: Record<string, string> = {};
    headers.forEach((header, idx) => {
      row[header] = values[idx]?.trim() ?? '';
    });

    const name = row.name || row['full name'] || row['first name'] || '';
    if (!name) continue;

    results.push({
      name,
      email: row.email || row['email address'] || null,
      phone: row.phone || row['phone number'] || row.whatsapp || null,
      company: row.company || row.organization || null,
      role: row.role || row.title || row['job title'] || null,
      industry: row.industry || row.sector || null,
      notes: row.notes || row['notes/comments'] || null,
      tags: row.tags ? row.tags.split(';').map((t) => t.trim()).filter(Boolean) : [],
    });
  }

  return results;
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current);
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}
