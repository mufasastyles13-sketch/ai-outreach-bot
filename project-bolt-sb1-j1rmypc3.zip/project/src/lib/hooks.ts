import { useEffect, useState, useCallback } from 'react';
import { supabase, Lead, Message } from './supabase';
import { useAuth } from './auth';

export function useLeads() {
  const { user } = useAuth();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchLeads = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('leads')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) setError(error.message);
    else setLeads(data ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchLeads();
  }, [fetchLeads]);

  const addLead = async (lead: Partial<Lead>) => {
    const { data, error } = await supabase
      .from('leads')
      .insert({
        name: lead.name!,
        email: lead.email ?? null,
        phone: lead.phone ?? null,
        company: lead.company ?? null,
        role: lead.role ?? null,
        industry: lead.industry ?? null,
        notes: lead.notes ?? null,
        tags: lead.tags ?? [],
        status: lead.status ?? 'new',
      })
      .select()
      .single();

    if (error) throw error;
    setLeads((prev) => [data, ...prev]);
    return data;
  };

  const addLeadsBatch = async (newLeads: Partial<Lead>[]) => {
    const rows = newLeads.map((l) => ({
      name: l.name!,
      email: l.email ?? null,
      phone: l.phone ?? null,
      company: l.company ?? null,
      role: l.role ?? null,
      industry: l.industry ?? null,
      notes: l.notes ?? null,
      tags: l.tags ?? [],
      status: 'new' as const,
    }));

    const { data, error } = await supabase.from('leads').insert(rows).select();
    if (error) throw error;
    setLeads((prev) => [...(data ?? []), ...prev]);
    return data ?? [];
  };

  const updateLead = async (id: string, updates: Partial<Lead>) => {
    const { data, error } = await supabase
      .from('leads')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    setLeads((prev) => prev.map((l) => (l.id === id ? data : l)));
    return data;
  };

  const deleteLead = async (id: string) => {
    const { error } = await supabase.from('leads').delete().eq('id', id);
    if (error) throw error;
    setLeads((prev) => prev.filter((l) => l.id !== id));
  };

  return { leads, loading, error, fetchLeads, addLead, addLeadsBatch, updateLead, deleteLead };
}

export function useMessages() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMessages = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('messages')
      .select('*, leads(name, company)')
      .order('created_at', { ascending: false });

    if (error) setError(error.message);
    else setMessages(data ?? []);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchMessages();
  }, [fetchMessages]);

  const addMessage = async (msg: Partial<Message>) => {
    const { data, error } = await supabase
      .from('messages')
      .insert({
        lead_id: msg.lead_id!,
        channel: msg.channel!,
        subject: msg.subject ?? null,
        body: msg.body!,
        tone: msg.tone ?? 'friendly',
        goal: msg.goal ?? null,
        status: msg.status ?? 'draft',
      })
      .select('*, leads(name, company)')
      .single();

    if (error) throw error;
    setMessages((prev) => [data, ...prev]);
    return data;
  };

  const updateMessage = async (id: string, updates: Partial<Message>) => {
    const { data, error } = await supabase
      .from('messages')
      .update(updates)
      .eq('id', id)
      .select('*, leads(name, company)')
      .single();

    if (error) throw error;
    setMessages((prev) => prev.map((m) => (m.id === id ? data : m)));
    return data;
  };

  const deleteMessage = async (id: string) => {
    const { error } = await supabase.from('messages').delete().eq('id', id);
    if (error) throw error;
    setMessages((prev) => prev.filter((m) => m.id !== id));
  };

  return { messages, loading, error, fetchMessages, addMessage, updateMessage, deleteMessage };
}
