import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

export type LeadStatus = 'new' | 'contacted' | 'responded' | 'closed';
export type MessageStatus = 'draft' | 'sent' | 'replied';
export type Channel = 'email' | 'whatsapp';
export type Tone = 'friendly' | 'formal' | 'concise' | 'persuasive';

export interface Lead {
  id: string;
  user_id: string;
  name: string;
  email: string | null;
  phone: string | null;
  company: string | null;
  role: string | null;
  industry: string | null;
  notes: string | null;
  tags: string[];
  status: LeadStatus;
  created_at: string;
}

export interface Message {
  id: string;
  user_id: string;
  lead_id: string;
  channel: Channel;
  subject: string | null;
  body: string;
  tone: Tone;
  goal: string | null;
  status: MessageStatus;
  created_at: string;
}

export type NewLead = Omit<Lead, 'id' | 'user_id' | 'created_at' | 'tags' | 'status'> & {
  tags?: string[];
  status?: LeadStatus;
};

export type NewMessage = Omit<Message, 'id' | 'user_id' | 'created_at' | 'status'> & {
  status?: MessageStatus;
};
