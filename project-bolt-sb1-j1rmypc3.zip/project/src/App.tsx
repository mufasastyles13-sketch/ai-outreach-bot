import { useEffect, useState } from 'react';
import { AuthProvider, useAuth } from './lib/auth';
import { LandingLayout } from './components/LandingLayout';
import { DashboardLayout } from './components/DashboardLayout';
import { HomePage } from './pages/landing/HomePage';
import { FeaturesPage } from './pages/landing/FeaturesPage';
import { PricingPage } from './pages/landing/PricingPage';
import { ContactPage } from './pages/landing/ContactPage';
import { AuthPage } from './pages/auth/AuthPage';
import { OverviewPage } from './pages/dashboard/OverviewPage';
import { LeadsPage } from './pages/dashboard/LeadsPage';
import { MessagesPage } from './pages/dashboard/MessagesPage';
import { BillingPage } from './pages/dashboard/BillingPage';
import { Spinner } from './components/ui';

function useHashRoute() {
  const [path, setPath] = useState(() => window.location.hash.replace('#', '') || '/');

  useEffect(() => {
    const onChange = () => {
      const newHash = window.location.hash.replace('#', '') || '/';
      setPath(newHash);
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);

  return path;
}

function Router() {
  const path = useHashRoute();
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Spinner className="h-8 w-8 text-brand-500" />
      </div>
    );
  }

  // Auth pages
  if (path === '/login') {
    if (user) {
      window.location.hash = '#/app';
      return null;
    }
    return <AuthPage mode="login" />;
  }

  if (path === '/signup') {
    if (user) {
      window.location.hash = '#/app';
      return null;
    }
    return <AuthPage mode="signup" />;
  }

  // Dashboard routes (protected)
  if (path.startsWith('/app')) {
    if (!user) {
      window.location.hash = '#/login';
      return null;
    }

    let content;
    if (path === '/app' || path === '/app/') {
      content = <OverviewPage />;
    } else if (path === '/app/leads') {
      content = <LeadsPage />;
    } else if (path === '/app/messages') {
      content = <MessagesPage />;
    } else if (path === '/app/billing') {
      content = <BillingPage />;
    } else {
      content = <OverviewPage />;
    }

    return (
      <DashboardLayout currentPath={path}>
        {content}
      </DashboardLayout>
    );
  }

  // Landing pages
  let landing;
  if (path === '/' || path === '') {
    landing = <HomePage />;
  } else if (path === '/features') {
    landing = <FeaturesPage />;
  } else if (path === '/pricing') {
    landing = <PricingPage />;
  } else if (path === '/contact') {
    landing = <ContactPage />;
  } else {
    landing = <HomePage />;
  }

  return (
    <LandingLayout currentPath={path}>
      {landing}
    </LandingLayout>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router />
    </AuthProvider>
  );
}
